# Transformer Pre-processing Lab

This repository contains my Jupyter notebook for the **Transformer Pre-processing** lab from Week 4 of the DeepLearning.AI [Sequence Models](https://www.coursera.org/learn/nlp-sequence-models) course.

##  Contents

- `Embedding_plus_Positional_encoding.ipynb` – Main notebook with the implementation of text preprocessing for Transformer models.
- `preprocessing.png` – Supporting image used in the notebook.

##  What I Did

In this lab, I:
- Implemented input embeddings and positional encoding for a Transformer architecture.
- Preprocessed raw text sequences for feeding into encoder and decoder blocks.

##  GloVe Embeddings

>  The GloVe embedding files (`glove/`) are not included in this repository to reduce the overall size.

To run the notebook properly, please download the GloVe embeddings from the official Stanford NLP website:

➡ [Download GloVe embeddings (glove.6B.zip)](https://nlp.stanford.edu/data/glove.6B.zip)

After downloading:
1. Extract the zip file.
2. Create a folder named `glove` in the same directory as the notebook.
3. Move the required `.txt` files into the `glove` folder.

##  How to Run

Open the notebook using Jupyter Notebook or JupyterLab:

```bash
jupyter notebook Embedding_plus_Positional_encoding.ipynb
